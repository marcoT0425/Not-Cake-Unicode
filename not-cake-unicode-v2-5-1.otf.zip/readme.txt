﻿The font file in this archive was created using Fontstruct the free, online
font-building tool.
This font was created by “marcotoa”*.
This font has a homepage where this archive and other versions may be found:
https://fontstruct.com/fontstructions/show/2672344

*NOTE: “Not_Cake Unicode V2.5.1” was originally cloned (copied) from the
FontStruction “A_not_cake unicode 1.6”
(https://fontstruct.com/fontstructions/show/2433705) by “marcot_0425”, which
is licensed under a Creative Commons Attribution Non-commercial Share Alike
license (http://creativecommons.org/licenses/by-nc-sa/3.0/).
“A_not_cake unicode 1.6” was in turn cloned (copied) from the FontStruction
“Enchrome New Unicode 1.2”
(https://fontstruct.com/fontstructions/show/2419975) by “marcot_0425”, which
is licensed under a Creative Commons Attribution Non-commercial Share Alike
license (http://creativecommons.org/licenses/by-nc-sa/3.0/).
“Enchrome New Unicode 1.2” was in turn cloned (copied) from the
FontStruction “Wikipedia Unicode”
(https://fontstruct.com/fontstructions/show/2419935) by “marcot_0425”, which
is licensed under a Creative Commons Attribution Non-commercial Share Alike
license (http://creativecommons.org/licenses/by-nc-sa/3.0/).
“Wikipedia Unicode” was in turn cloned (copied) from the FontStruction
“Enchrome Std Book” (https://fontstruct.com/fontstructions/show/2419895) by
“marcot_0425”, which is licensed under a Creative Commons Attribution
Non-commercial Share Alike license
(http://creativecommons.org/licenses/by-nc-sa/3.0/).
“Enchrome Std Book” was in turn cloned (copied) from the FontStruction
“Enchrome ASCII” (https://fontstruct.com/fontstructions/show/2419885) by
“marcot_0425”, which is licensed under a Creative Commons Attribution
Non-commercial Share Alike license
(http://creativecommons.org/licenses/by-nc-sa/3.0/).

Try Fontstruct at https://fontstruct.com
It’s easy and it’s fun.

Fontstruct is copyright ©2025 Rob Meek

LEGAL NOTICE:
In using this font you must comply with the licensing terms described in the
file “license.txt” included with this archive.
If you redistribute the font file in this archive, it must be accompanied by all
the other files from this archive, including this one.
